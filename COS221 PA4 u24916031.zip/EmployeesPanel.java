import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class EmployeesPanel extends Component implements ActionListener {
	Panel data;
	Database db = Database.getInstance();
	Panel root;
	Choice columnChoice;
	TextField filter;
	int numCols = 8;

	public Panel getRoot() {
		return root;
	}

	public EmployeesPanel() {
		root = new Panel(new BorderLayout());
		root.setBackground(Color.LIGHT_GRAY);
		Panel employeeFilter = new Panel(new FlowLayout(FlowLayout.LEFT));

		columnChoice = new Choice();
		columnChoice.add("First Name");
		columnChoice.add("Country");

		filter = new TextField(30);

		Button search = new Button("Search");
		search.addActionListener(this);

		employeeFilter.add(columnChoice);
		employeeFilter.add(filter);
		employeeFilter.add(search);
		ScrollPane scrollPane = new ScrollPane(ScrollPane.SCROLLBARS_AS_NEEDED);
		scrollPane.setBackground(Color.RED);

		data = new Panel(new GridLayout(0, numCols, 1, 1));
		data.setBackground(Color.DARK_GRAY);

		updateData();

		scrollPane.add(data, 0);
		root.add(employeeFilter, BorderLayout.NORTH);
		root.add(scrollPane, BorderLayout.CENTER);
	}

	private void updateData() {
		data.removeAll();
		data.setBackground(Color.DARK_GRAY);
		data.add(createCell("First Name", true));
		data.add(createCell("Last Name", true));
		data.add(createCell("Title", true));
		data.add(createCell("City", true));
		data.add(createCell("Country", true));
		data.add(createCell("Phone", true));
		data.add(createCell("Reports-to", true));
		data.add(createCell("Active", true));

		String colString;
		switch (columnChoice.getSelectedItem()) {
			case ("First Name"): {
				colString = "firstname";
				break;
			}
			case ("Country"): {
				colString = "country";
				break;
			}
			default: {
				colString = "";
			}
		}

		ArrayList<String[]> ret = db.getEmployees(colString, filter.getText());
		for (int i = 0; i < ret.size(); i++) {
			for (int j = 0; j < ret.get(i).length; j++) {
				data.add(createCell(ret.get(i)[j], false));
			}
		}

		int rowCount = (data.getComponentCount() / numCols);
		int fixedRowHeight = 30;

		data.setPreferredSize(new Dimension(1280, rowCount * fixedRowHeight));

		data.revalidate();
		data.repaint();
	}

	private Label createCell(String text, boolean isHeader) {
		Label label = new Label(text, Label.CENTER);
		if (isHeader) {
			label.setFont(new Font("Arial", Font.BOLD, 12));
		}
		label.setBackground(isHeader ? Color.GRAY : Color.LIGHT_GRAY);

		return label;
	}

	public void actionPerformed(ActionEvent e) {

		updateData();
	}
}
